"use client";

import { useMemo, useState } from "react";
import { ArrowDownWideNarrow, ArrowRight, BookOpen, Check, LayoutGrid, List, MoreHorizontal, Plus, Search, SlidersHorizontal } from "lucide-react";
import { useLibrary } from "./library-provider";
import { Cover, EmptyState, Rating } from "./ui";
import { bookPercent } from "@/lib/stats";
import { statusLabels, type Book, type BookStatus } from "@/lib/types";

type Filter = "all" | BookStatus;
export function BookCollection({ overview = false, shelfId, query = "", onViewLibrary, onClearQuery, initialFilter = "all" }: { overview?: boolean; shelfId?: string; query?: string; onViewLibrary?: () => void; onClearQuery?: () => void; initialFilter?: Filter }) {
  const { data, setDialog } = useLibrary();
  const [filter, setFilter] = useState<Filter>(initialFilter);
  const [genre, setGenre] = useState("");
  const [sort, setSort] = useState("recent");
  const [layout, setLayout] = useState<"shelf" | "list">("shelf");
  const baseBooks = useMemo(() => data?.books.filter(book => !shelfId || book.shelfIds.includes(shelfId)) ?? [], [data?.books, shelfId]);
  const availableGenres = [...new Set(baseBooks.map(book => book.genre))].sort();
  const matchedBooks = useMemo(() => {
    const filtered = baseBooks.filter(book => (filter === "all" || book.status === filter) && (!genre || book.genre === genre) && (!query || `${book.title} ${book.author} ${book.genre}`.toLowerCase().includes(query.toLowerCase())));
    if (sort === "title") filtered.sort((a, b) => a.title.localeCompare(b.title));
    if (sort === "author") filtered.sort((a, b) => a.author.localeCompare(b.author));
    if (sort === "rating") filtered.sort((a, b) => b.rating - a.rating);
    if (overview && filter === "all" && !genre && !query) return [...filtered.filter(book => book.status !== "reading"), ...filtered.filter(book => book.status === "reading")];
    return filtered;
  }, [baseBooks, filter, genre, query, sort, overview]);
  const visible = overview ? matchedBooks.slice(0, 6) : matchedBooks;
  const filters: { value: Filter; label: string }[] = [{ value: "all", label: "All books" }, { value: "reading", label: "Reading" }, { value: "want-to-read", label: "Want to read" }, { value: "finished", label: "Finished" }];
  return <section className={`collection-section ${overview ? "collection-overview" : ""}`}>
    {overview && <div className="section-heading"><div><h2>Your bookshelf <span className="section-count">{baseBooks.length}</span></h2><p>A collection that’s uniquely you.</p></div><button className="text-button" onClick={onViewLibrary}>View library <ArrowRight size={15} /></button></div>}
    <div className="collection-toolbar"><div className="collection-tabs" role="tablist" aria-label="Filter books by reading status">{filters.map(item => <button key={item.value} role="tab" aria-selected={filter === item.value} className={filter === item.value ? "active" : ""} onClick={() => setFilter(item.value)}>{item.label}<span>{item.value === "all" ? baseBooks.length : baseBooks.filter(book => book.status === item.value).length}</span></button>)}</div><div className="collection-controls">
      <label className="select-control"><SlidersHorizontal size={14} /><select value={genre} onChange={event => setGenre(event.target.value)} aria-label="Filter by genre"><option value="">All genres</option>{availableGenres.map(item => <option key={item}>{item}</option>)}</select></label>
      {!overview && <label className="select-control sort-control"><ArrowDownWideNarrow size={14} /><select value={sort} onChange={event => setSort(event.target.value)} aria-label="Sort books"><option value="recent">Recently added</option><option value="title">Title A–Z</option><option value="author">Author A–Z</option><option value="rating">Highest rated</option></select></label>}
      <div className="view-toggle"><button className={layout === "shelf" ? "active" : ""} onClick={() => setLayout("shelf")} aria-label="Bookshelf view" aria-pressed={layout === "shelf"}><LayoutGrid size={16} /></button><button className={layout === "list" ? "active" : ""} onClick={() => setLayout("list")} aria-label="List view" aria-pressed={layout === "list"}><List size={17} /></button></div>
    </div></div>
    {query && <div className="search-summary"><Search size={14} /> {matchedBooks.length} {matchedBooks.length === 1 ? "result" : "results"} for <strong>“{query}”</strong></div>}
    {!visible.length ? <EmptyState title={baseBooks.length ? "No books in this little corner. Yet." : shelfId ? "A shelf waiting for its first story." : "Your next chapter starts here."} description={baseBooks.length ? "Try another title, author, or filter to find your next read." : "Add a book you love, or one you’ve always wanted to read."} action={baseBooks.length ? <button className="button secondary" onClick={() => { setFilter("all"); setGenre(""); onClearQuery?.(); }}>{query ? "Clear search & filters" : "Reset filters"}</button> : <button className="button primary" onClick={() => setDialog(shelfId ? { type: "shelf-form", shelfId } : { type: "book-form" })}><Plus size={16} />{shelfId ? "Add books to shelf" : "Add your first book"}</button>} /> : layout === "shelf" ? <div className="bookshelf-grid">{visible.map(book => <BookTile key={book.id} book={book} />)}</div> : <div className="book-table-wrap"><table className="book-table"><thead><tr><th>Book</th><th>Status</th><th>Progress</th><th>Your rating</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>{visible.map(book => <tr key={book.id}><td><button className="table-book" onClick={() => setDialog({ type: "book", bookId: book.id })}><Cover cover={book.cover} title={book.title} author={book.author} /><span><strong>{book.title}</strong><small>{book.author}</small></span></button></td><td><span className={`status-tag ${book.status}`}>{statusLabels[book.status]}</span></td><td><span className="table-percent">{bookPercent(book.currentPage, book.totalPages)}%</span><div className="progress-track"><span style={{ width: `${bookPercent(book.currentPage, book.totalPages)}%` }} /></div></td><td><Rating value={book.rating} /></td><td><button className="icon-button" aria-label={`Details for ${book.title}`} onClick={() => setDialog({ type: "book", bookId: book.id })}><MoreHorizontal size={18} /></button></td></tr>)}</tbody></table></div>}
    {visible.length > 0 && <div className="collection-footer"><span>{overview ? `${visible.length} of ${baseBooks.length} books, and so many worlds to explore.` : `${visible.length} ${visible.length === 1 ? "book" : "books"} on your shelf`}</span>{overview && <button className="text-button" onClick={onViewLibrary}>See your whole collection <ArrowRight size={13} /></button>}</div>}
  </section>;
}

function BookTile({ book }: { book: Book }) {
  const { setDialog } = useLibrary();
  const pending = book.id.startsWith("pending-");
  return <article className={`book-tile ${pending ? "pending" : ""}`}>
    <div className="cover-stage"><button className="cover-button" onClick={() => setDialog({ type: "book", bookId: book.id })} disabled={pending} aria-label={`Open ${book.title}`}><Cover cover={book.cover} title={book.title} author={book.author} /></button><button className="book-quick-action" onClick={() => setDialog({ type: "book", bookId: book.id })} disabled={pending} aria-label={`More about ${book.title}`}><MoreHorizontal size={17} /></button></div>
    <div className="book-tile-details"><button className="book-title-button" onClick={() => setDialog({ type: "book", bookId: book.id })} disabled={pending}>{book.title}</button><p>{book.author}</p><div className="book-tile-bottom">{book.rating > 0 ? <Rating value={book.rating} size={12} /> : <span className={`tiny-status ${book.status}`}>{book.status === "finished" ? <Check size={12} /> : book.status === "reading" ? <BookOpen size={12} /> : null}{statusLabels[book.status]}</span>}</div></div>
  </article>;
}
