"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { BookOpen, Check, Loader2, Star, X } from "lucide-react";

export function Cover({ cover, title, author = "", className = "", eager = false }: { cover: string; title: string; author?: string; className?: string; eager?: boolean }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [cover]);
  const palettes = ["#41594b", "#ac755e", "#74878d", "#b7a379", "#6d6683"];
  const color = palettes[title.split("").reduce((sum, character) => sum + character.charCodeAt(0), 0) % palettes.length];
  return <div className={`book-cover ${className}`} style={{ backgroundColor: color }}>
    {cover && !failed ? <img src={cover} alt={`${title} book cover`} loading={eager ? "eager" : "lazy"} onError={() => setFailed(true)} /> : <div className="cover-fallback"><BookOpen size={22} strokeWidth={1.3} /><strong>{title}</strong><span>{author}</span></div>}
    <span className="cover-binding" />
  </div>;
}

export function Rating({ value, onChange, size = 13, disabled = false }: { value: number; onChange?: (value: number) => void; size?: number; disabled?: boolean }) {
  const [hover, setHover] = useState(0);
  const shown = hover || value;
  if (!onChange) return <span className="rating" aria-label={`${value} out of 5 stars`}>{[1, 2, 3, 4, 5].map(star => <Star key={star} size={size} strokeWidth={1.5} className={star <= value ? "star-filled" : "star-empty"} fill="currentColor" />)}</span>;
  return <span className="rating rating-interactive" role="group" aria-label="Your book rating" onMouseLeave={() => setHover(0)}>{[1, 2, 3, 4, 5].map(star => <button type="button" disabled={disabled} key={star} onMouseEnter={() => setHover(star)} onFocus={() => setHover(star)} onBlur={() => setHover(0)} onClick={() => onChange(star === value ? 0 : star)} aria-label={`Rate ${star} ${star === 1 ? "star" : "stars"}`} aria-pressed={star === value}><Star size={size} strokeWidth={1.5} className={star <= shown ? "star-filled" : "star-empty"} fill="currentColor" /></button>)}</span>;
}

export function Modal({ title, subtitle, children, className = "", onClose }: { title: string; subtitle?: string; children: ReactNode; className?: string; onClose: () => void }) {
  const panel = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose); onCloseRef.current = onClose;
  useEffect(() => {
    const previousFocus = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const timeout = setTimeout(() => { const initial = panel.current?.querySelector<HTMLElement>("[data-autofocus], input:not([type=checkbox]), textarea, button"); initial?.focus(); }, 50);
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onCloseRef.current();
      if (event.key === "Tab") {
        const items = panel.current?.querySelectorAll<HTMLElement>('button:not([disabled]), [href], input:not([disabled]), select, textarea, [tabindex="0"]');
        if (!items?.length) return;
        const first = items[0]; const last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener("keydown", keydown);
    return () => { clearTimeout(timeout); document.body.style.overflow = previousOverflow; document.removeEventListener("keydown", keydown); previousFocus?.focus(); };
  }, []);
  return <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}><div className={`modal-panel ${className}`} role="dialog" aria-modal="true" aria-labelledby="dialog-title" ref={panel}>
    <div className="modal-heading"><div><h2 id="dialog-title">{title}</h2>{subtitle && <p>{subtitle}</p>}</div><button className="icon-button close-button" onClick={onClose} aria-label="Close dialog"><X size={19} /></button></div>{children}
  </div></div>;
}

export function SubmitButton({ children, busy, className = "", ...props }: { children: ReactNode; busy?: boolean; className?: string; disabled?: boolean; type?: "button" | "submit"; onClick?: () => void }) {
  return <button className={`button primary ${className}`} disabled={busy || props.disabled} type={props.type ?? "submit"} onClick={props.onClick}>{busy ? <Loader2 size={16} className="spin" /> : null}{children}</button>;
}
export function FormError({ error }: { error: string | null }) { return error ? <div className="form-error" role="alert">{error}</div> : null; }
export function EmptyState({ title, description, action, icon }: { title: string; description: string; action?: ReactNode; icon?: ReactNode }) {
  return <div className="empty-state"><div className="empty-icon">{icon ?? <BookOpen size={28} strokeWidth={1.3} />}</div><h3>{title}</h3><p>{description}</p>{action}</div>;
}
export function Toast({ message, tone }: { message: string; tone: "success" | "error" }) {
  return <div className={`toast ${tone}`} role="status" aria-live="polite"><span className="toast-icon">{tone === "success" ? <Check size={16} /> : <X size={16} />}</span>{message}</div>;
}
export function DashboardSkeleton() {
  return <div className="dashboard-skeleton" aria-label="Loading your library" aria-busy="true"><div className="skeleton skeleton-title" /><div className="skeleton skeleton-subtitle" /><div className="skeleton-stats">{[1, 2, 3, 4].map(n => <div className="skeleton" key={n} />)}</div><div className="skeleton skeleton-hero" /><div className="skeleton skeleton-title" /><div className="skeleton-reading">{[1, 2, 3].map(n => <div className="skeleton" key={n} />)}</div><div className="skeleton skeleton-hero" /></div>;
}
