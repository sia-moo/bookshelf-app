"use client";

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import type { Book, LibraryData, ReadingLog, Shelf, User } from "@/lib/types";

export type DialogState =
  | { type: "book"; bookId: string }
  | { type: "book-form"; bookId?: string }
  | { type: "progress"; bookId: string }
  | { type: "shelf-form"; shelfId?: string }
  | { type: "goal" }
  | { type: "auth"; mode: "login" | "signup" }
  | { type: "confirm"; resource: "book" | "shelf" | "log"; id: string; title: string }
  | { type: "help" }
  | null;
export type BookPayload = Partial<Book> & { minutes?: number };
export type ShelfPayload = Partial<Shelf> & { bookIds: string[] };

type LibraryContextType = {
  data: LibraryData | null; loading: boolean; error: string | null;
  dialog: DialogState; setDialog: (dialog: DialogState) => void;
  toast: { message: string; tone: "success" | "error" } | null;
  notify: (message: string, tone?: "success" | "error") => void;
  refresh: () => Promise<void>;
  updateBook: (id: string, payload: BookPayload, message?: string) => Promise<Book>;
  addBook: (payload: BookPayload) => Promise<Book>;
  saveShelf: (id: string | undefined, payload: ShelfPayload) => Promise<void>;
  deleteResource: (resource: "book" | "shelf" | "log", id: string) => Promise<void>;
  updateProfile: (payload: Partial<User>) => Promise<void>;
};
const LibraryContext = createContext<LibraryContextType | null>(null);

export async function apiRequest<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...options, headers: { "Content-Type": "application/json", ...options?.headers }, cache: "no-store" });
  let result;
  try { result = await response.json(); } catch { throw new Error("We couldn't connect. Please try again."); }
  if (!response.ok) throw new Error(result.error ?? "Something went wrong. Please try again.");
  return result as T;
}
const errorMessage = (error: unknown) => error instanceof Error ? error.message : "Something went wrong. Please try again.";

let initialRequest: Promise<LibraryData> | null = null;
export function LibraryProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<LibraryData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dialog, setDialog] = useState<DialogState>(null);
  const [toast, setToast] = useState<LibraryContextType["toast"]>(null);
  const notify = useCallback((message: string, tone: "success" | "error" = "success") => setToast({ message, tone }), []);
  useEffect(() => { if (!toast) return; const timeout = setTimeout(() => setToast(null), 4500); return () => clearTimeout(timeout); }, [toast]);
  useEffect(() => {
    let active = true;
    if (!initialRequest) initialRequest = apiRequest<LibraryData>("/api/library");
    initialRequest.then(result => { if (active) { setData(result); setError(null); } }).catch(error => { if (active) setError(errorMessage(error)); }).finally(() => { initialRequest = null; if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  const refresh = useCallback(async () => {
    setError(null);
    try { const result = await apiRequest<LibraryData>("/api/library"); setData(result); }
    catch (error) { setError(errorMessage(error)); throw error; }
    finally { setLoading(false); }
  }, []);

  const updateBook = async (id: string, payload: BookPayload, message?: string) => {
    const original = data?.books.find(book => book.id === id);
    const optimistic = { ...payload };
    if (payload.status === "finished" && original) { optimistic.currentPage = payload.totalPages ?? original.totalPages; optimistic.finishedAt = new Date().toISOString(); }
    if (payload.status === "want-to-read") { optimistic.currentPage = 0; optimistic.finishedAt = null; }
    if (payload.currentPage !== undefined && original && payload.currentPage === original.totalPages) { optimistic.status = "finished"; optimistic.finishedAt = new Date().toISOString(); }
    setData(prev => prev ? { ...prev, books: prev.books.map(book => book.id === id ? { ...book, ...optimistic } : book) } : prev);
    try {
      const result = await apiRequest<{ book: Book; log: ReadingLog | null }>(`/api/books/${id}`, { method: "PATCH", body: JSON.stringify(payload) });
      setData(prev => prev ? { ...prev, books: prev.books.map(book => book.id === id ? result.book : book), logs: result.log ? [result.log, ...prev.logs] : prev.logs } : prev);
      if (message) notify(message);
      return result.book;
    } catch (error) {
      if (original) setData(prev => prev ? { ...prev, books: prev.books.map(book => book.id === id ? original : book) } : prev);
      notify(errorMessage(error), "error"); throw error;
    }
  };

  const addBook = async (payload: BookPayload) => {
    const id = `pending-${Date.now()}`;
    const optimistic: Book = { id, userId: data?.user.id ?? "", title: "Untitled", author: "", cover: "", genre: "Fiction", totalPages: 300, currentPage: 0, status: "want-to-read", rating: 0, notes: "", description: "", addedAt: new Date().toISOString(), finishedAt: null, shelfIds: [], ...payload };
    setData(prev => prev ? { ...prev, books: [optimistic, ...prev.books] } : prev);
    try {
      const result = await apiRequest<{ book: Book }>("/api/books", { method: "POST", body: JSON.stringify(payload) });
      setData(prev => prev ? { ...prev, books: prev.books.map(book => book.id === id ? result.book : book) } : prev);
      notify(`“${result.book.title}” has a place on your shelf.`);
      return result.book;
    } catch (error) {
      setData(prev => prev ? { ...prev, books: prev.books.filter(book => book.id !== id) } : prev);
      notify(errorMessage(error), "error"); throw error;
    }
  };

  const saveShelf = async (id: string | undefined, payload: ShelfPayload) => {
    const result = await apiRequest<{ shelf: Shelf; bookIds: string[] }>(id ? `/api/shelves/${id}` : "/api/shelves", { method: id ? "PATCH" : "POST", body: JSON.stringify(payload) });
    setData(prev => prev ? {
      ...prev, shelves: id ? prev.shelves.map(shelf => shelf.id === id ? result.shelf : shelf) : [...prev.shelves, result.shelf],
      books: prev.books.map(book => ({ ...book, shelfIds: result.bookIds.includes(book.id) ? [...new Set([...book.shelfIds, result.shelf.id])] : book.shelfIds.filter(shelfId => shelfId !== result.shelf.id) })),
    } : prev);
    notify(id ? "Shelf updated. Looking lovely." : "A new shelf, a world of possibilities.");
  };

  const deleteResource = async (resource: "book" | "shelf" | "log", id: string) => {
    const snapshot = data;
    setData(prev => prev ? {
      ...prev,
      books: resource === "book" ? prev.books.filter(book => book.id !== id) : resource === "shelf" ? prev.books.map(book => ({ ...book, shelfIds: book.shelfIds.filter(shelfId => shelfId !== id) })) : prev.books,
      shelves: resource === "shelf" ? prev.shelves.filter(shelf => shelf.id !== id) : prev.shelves,
      logs: resource === "log" ? prev.logs.filter(log => log.id !== id) : resource === "book" ? prev.logs.filter(log => log.bookId !== id) : prev.logs,
    } : prev);
    try {
      await apiRequest(`/api/${resource === "book" ? "books" : resource === "shelf" ? "shelves" : "reading"}/${id}`, { method: "DELETE" });
      notify(resource === "book" ? "Book removed from your library." : resource === "shelf" ? "Shelf removed. Your books are still in your library." : "Reading session removed.");
    } catch (error) { setData(snapshot); notify(errorMessage(error), "error"); throw error; }
  };

  const updateProfile = async (payload: Partial<User>) => {
    const original = data?.user;
    setData(prev => prev ? { ...prev, user: { ...prev.user, ...payload } } : prev);
    try {
      const result = await apiRequest<{ user: User }>("/api/profile", { method: "PATCH", body: JSON.stringify(payload) });
      setData(prev => prev ? { ...prev, user: result.user } : prev);
      notify(payload.readingGoal ? "Your next chapter is set. You've got this!" : "Your profile has been updated.");
    } catch (error) { if (original) setData(prev => prev ? { ...prev, user: original } : prev); notify(errorMessage(error), "error"); throw error; }
  };

  return <LibraryContext.Provider value={{ data, loading, error, dialog, setDialog, toast, notify, refresh, updateBook, addBook, saveShelf, deleteResource, updateProfile }}>{children}</LibraryContext.Provider>;
}
export function useLibrary() { const context = useContext(LibraryContext); if (!context) throw new Error("LibraryProvider is missing"); return context; }
