"use client";

import { useState, type FormEvent } from "react";
import { ArrowRight, BookMarked, BookOpen, Check, CheckCircle2, ChevronRight, Eye, EyeOff, Flower2, Heart, Leaf, LockKeyhole, Pencil, Plus, Search, ShieldCheck, Sparkles, Target, Trash2 } from "lucide-react";
import { bookPercent } from "@/lib/stats";
import { genres, statusLabels, type Book, type BookStatus, type Shelf } from "@/lib/types";
import { apiRequest, useLibrary } from "./library-provider";
import { Cover, FormError, Modal, Rating, SubmitButton } from "./ui";

const getError = (error: unknown) => error instanceof Error ? error.message : "Something went wrong. Please try again.";

export function Dialogs() {
  const { dialog, data, setDialog } = useLibrary();
  if (!dialog || !data) return null;
  const close = () => setDialog(null);
  if (dialog.type === "book-form") return <BookFormDialog key={dialog.bookId ?? "new"} book={data.books.find(book => book.id === dialog.bookId)} onClose={close} />;
  if (dialog.type === "book" || dialog.type === "progress") {
    const book = data.books.find(book => book.id === dialog.bookId);
    if (!book) return null;
    return dialog.type === "book" ? <BookDetailsDialog key={book.id} book={book} onClose={close} /> : <ProgressDialog key={book.id} book={book} onClose={close} />;
  }
  if (dialog.type === "shelf-form") return <ShelfFormDialog key={dialog.shelfId ?? "new"} shelf={data.shelves.find(shelf => shelf.id === dialog.shelfId)} onClose={close} />;
  if (dialog.type === "goal") return <GoalDialog onClose={close} />;
  if (dialog.type === "auth") return <AuthDialog key={dialog.mode} mode={dialog.mode} onClose={close} />;
  if (dialog.type === "confirm") return <ConfirmDialog resource={dialog.resource} id={dialog.id} title={dialog.title} onClose={close} />;
  return <HelpDialog onClose={close} />;
}

function BookFormDialog({ book, onClose }: { book?: Book; onClose: () => void }) {
  const { data, addBook, updateBook } = useLibrary();
  const [title, setTitle] = useState(book?.title ?? "");
  const [author, setAuthor] = useState(book?.author ?? "");
  const [cover, setCover] = useState(book?.cover ?? "");
  const [genre, setGenre] = useState(book?.genre ?? "Fiction");
  const [pages, setPages] = useState(book?.totalPages ?? 300);
  const [status, setStatus] = useState<BookStatus>(book?.status ?? "want-to-read");
  const [description, setDescription] = useState(book?.description ?? "");
  const [shelfIds, setShelfIds] = useState(book?.shelfIds ?? []);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError(null);
    try {
      const payload = { title, author, cover, genre, totalPages: pages, status, description, shelfIds };
      if (book) await updateBook(book.id, payload, "Book updated. The story continues."); else await addBook(payload);
      onClose();
    } catch (error) { setError(getError(error)); } finally { setBusy(false); }
  };
  return <Modal title={book ? "A little shelf maintenance." : "Make room for a new story."} subtitle={book ? "Keep the details of your book just right." : "Add a favorite, a recommendation, or your next great read."} onClose={onClose} className="book-form-modal"><form onSubmit={submit}>
    <div className="book-form-top"><Cover cover={cover} title={title || "Your next great read"} author={author} /><div className="book-form-main"><label className="field-label">Book title <span>*</span><input data-autofocus value={title} onChange={event => setTitle(event.target.value)} placeholder="Every great story has a name" required maxLength={250} /></label><label className="field-label">Author <span>*</span><input value={author} onChange={event => setAuthor(event.target.value)} placeholder="Who wrote it?" required maxLength={250} /></label></div></div>
    <div className="form-columns"><label className="field-label">Genre<select value={genre} onChange={event => setGenre(event.target.value)}>{[...new Set([...genres, genre])].map(item => <option key={item}>{item}</option>)}</select></label><label className="field-label">Number of pages<input type="number" min={1} max={20000} value={pages || ""} onChange={event => setPages(Number(event.target.value))} required /></label></div>
    <label className="field-label">Reading status<select value={status} onChange={event => setStatus(event.target.value as BookStatus)}>{Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
    <label className="field-label">Cover image URL <span className="optional">optional</span><input value={cover} onChange={event => setCover(event.target.value)} placeholder="https://example.com/your-book-cover.jpg" maxLength={2000} /><small>No image? We’ll make your book a lovely cover.</small></label>
    <label className="field-label">About this book <span className="optional">optional</span><textarea value={description} onChange={event => setDescription(event.target.value)} placeholder="A few words about the world inside…" rows={3} maxLength={5000} /></label>
    {Boolean(data?.shelves.length) && <fieldset className="shelf-checkbox-field"><legend>Add to a shelf <span className="optional">optional</span></legend><div className="shelf-checkboxes">{data?.shelves.map(shelf => <label className={`shelf-chip ${shelfIds.includes(shelf.id) ? "selected" : ""}`} key={shelf.id}><input type="checkbox" checked={shelfIds.includes(shelf.id)} onChange={() => setShelfIds(prev => prev.includes(shelf.id) ? prev.filter(id => id !== shelf.id) : [...prev, shelf.id])} /><span className="color-dot" style={{ background: shelf.color }} />{shelf.name}{shelfIds.includes(shelf.id) && <Check size={12} />}</label>)}</div></fieldset>}
    <FormError error={error} /><div className="modal-footer"><button className="button secondary" type="button" onClick={onClose}>Cancel</button><SubmitButton busy={busy}>{book ? "Save changes" : <><Plus size={15} />Add to my library</>}</SubmitButton></div>
  </form></Modal>;
}

function BookDetailsDialog({ book, onClose }: { book: Book; onClose: () => void }) {
  const { data, updateBook, setDialog, notify } = useLibrary();
  const [tab, setTab] = useState("about");
  const [notes, setNotes] = useState(book.notes);
  const [busy, setBusy] = useState(false);
  const percent = bookPercent(book.currentPage, book.totalPages);
  const change = async (payload: Partial<Book>, message?: string) => { setBusy(true); try { await updateBook(book.id, payload, message); } catch {} finally { setBusy(false); } };
  return <Modal title="A closer look." onClose={onClose} className="book-details-modal"><div className="book-details-hero"><Cover cover={book.cover} title={book.title} author={book.author} eager /><div><span className="eyebrow">{book.genre}</span><h3>{book.title}</h3><p className="detail-author">by {book.author}</p><span className="detail-pages">{book.totalPages} pages <span>·</span> In your library since {new Date(book.addedAt).toLocaleDateString("en", { month: "short", year: "numeric" })}</span><div className="detail-rating"><Rating value={book.rating} size={21} disabled={busy} onChange={rating => void change({ rating }, rating ? "A little love, saved to your shelf." : "Rating cleared.")} /><span>{book.rating ? `${book.rating} / 5 — your rating` : "How did it make you feel?"}</span></div></div></div>
    <div className="status-selector" aria-label="Reading status">{(Object.entries(statusLabels) as [BookStatus, string][]).map(([value, label]) => <button key={value} className={book.status === value ? "active" : ""} disabled={busy} onClick={() => void change({ status: value }, value === "finished" ? "Another world explored. Book marked as finished!" : "Reading status updated.")}>{value === "want-to-read" ? <BookMarked size={15} /> : value === "reading" ? <BookOpen size={15} /> : <CheckCircle2 size={15} />}{label}</button>)}</div>
    {book.status !== "want-to-read" && <div className="detail-progress"><div><span>{book.status === "finished" ? "Every page, a part of your story." : "Your place in the story"}</span><strong>{percent}%</strong></div><div className="progress-track"><span style={{ width: `${percent}%` }} /></div><div><small>Page {book.currentPage} of {book.totalPages}</small><button className="text-button" onClick={() => setDialog({ type: "progress", bookId: book.id })}>Update progress <ArrowRight size={13} /></button></div></div>}
    <div className="details-tabs" role="tablist" aria-label="Book details">{[{ id: "about", label: "About the book" }, { id: "notes", label: "My notes" }, { id: "shelves", label: "On my shelves" }].map(item => <button key={item.id} role="tab" aria-selected={tab === item.id} className={tab === item.id ? "active" : ""} onClick={() => setTab(item.id)}>{item.label}</button>)}</div>
    <div className="details-tab-content" role="tabpanel">{tab === "about" ? <><p>{book.description || "Every book has a story. Add a description to capture what makes this one special."}</p><div className="book-detail-facts"><span><BookOpen size={15} />{book.totalPages} pages</span><span><Leaf size={15} />{book.genre}</span>{book.finishedAt && <span><Check size={15} />Finished {new Date(book.finishedAt).toLocaleDateString("en", { month: "short", day: "numeric" })}</span>}</div></> : tab === "notes" ? <><label className="field-label">The things you want to remember<textarea value={notes} onChange={event => setNotes(event.target.value)} placeholder="A thought, a favorite line, a little moment that stayed with you…" rows={6} maxLength={20000} /></label><div className="notes-footer"><span>Just for you. Saved to your library.</span><SubmitButton type="button" busy={busy} onClick={() => void change({ notes }, "Your thoughts have a safe little home.")}>Save notes</SubmitButton></div></> : <div className="details-shelves">{data?.shelves.length ? data.shelves.map(shelf => <label className="detail-shelf-row" key={shelf.id}><span className="color-dot" style={{ background: shelf.color }} /><span>{shelf.name}</span><input type="checkbox" disabled={busy} checked={book.shelfIds.includes(shelf.id)} onChange={() => void change({ shelfIds: book.shelfIds.includes(shelf.id) ? book.shelfIds.filter(id => id !== shelf.id) : [...book.shelfIds, shelf.id] }, "Your shelf is looking a little more like you.")} /></label>) : <p className="muted">No shelves yet. Create a little home for this story.</p>}<button className="text-button" onClick={() => setDialog({ type: "shelf-form" })}><Plus size={14} />Create a new shelf</button></div>}</div>
    <div className="modal-footer details-footer"><button className="text-button danger-text" onClick={() => setDialog({ type: "confirm", resource: "book", id: book.id, title: book.title })}><Trash2 size={14} />Remove book</button><button className="button secondary" onClick={() => setDialog({ type: "book-form", bookId: book.id })}><Pencil size={14} />Edit book</button></div>
  </Modal>;
}

function ProgressDialog({ book, onClose }: { book: Book; onClose: () => void }) {
  const { updateBook } = useLibrary();
  const [page, setPage] = useState(book.currentPage);
  const [minutes, setMinutes] = useState(25);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError(null);
    try { await updateBook(book.id, { currentPage: page, minutes, ...(page > 0 && book.status === "want-to-read" ? { status: "reading" as const } : {}) }, page === book.totalPages ? "The last page, but never the end. Book finished!" : `${Math.max(0, page - book.currentPage)} more pages in your story. Progress saved.`); onClose(); } catch (error) { setError(getError(error)); } finally { setBusy(false); }
  };
  return <Modal title="One page closer." subtitle="Every little reading moment counts." onClose={onClose} className="progress-modal"><form onSubmit={submit}><div className="progress-book"><Cover cover={book.cover} title={book.title} author={book.author} /><div><h3>{book.title}</h3><p>{book.author}</p><span>You left off on page {book.currentPage}.</span></div></div><div className="progress-input-heading"><label htmlFor="current-page">Where are you up to?</label><span>{bookPercent(page, book.totalPages)}% complete</span></div><div className="page-number-field"><span>Page</span><input data-autofocus id="current-page" type="number" min={0} max={book.totalPages} value={page} onChange={event => setPage(Math.min(book.totalPages, Math.max(0, Number(event.target.value))))} required /><span>of {book.totalPages}</span></div><input className="page-slider" aria-label="Reading progress" type="range" min={0} max={book.totalPages} value={page} onChange={event => setPage(Number(event.target.value))} style={{ background: `linear-gradient(to right, var(--green) ${bookPercent(page, book.totalPages)}%, #e7eae2 ${bookPercent(page, book.totalPages)}%)` }} /><div className="slider-labels"><span>The beginning</span><span>The last page</span></div><label className="finished-checkbox"><input type="checkbox" checked={page === book.totalPages} onChange={event => setPage(event.target.checked ? book.totalPages : book.currentPage)} /><CheckCircle2 size={17} />I’ve finished this book!</label><label className="field-label minutes-field">Time spent reading<div><input type="number" min={1} max={1440} value={minutes} onChange={event => setMinutes(Number(event.target.value))} required /><span>minutes</span></div></label><div className="gentle-note"><Leaf size={14} />{page < book.currentPage ? "Revisiting a chapter? We’ll update your place without adding a reading session." : page === book.currentPage ? "Your bookmark is safe. Move it forward to log a reading session." : `${page - book.currentPage} pages of good company. Lovely.`}</div><FormError error={error} /><div className="modal-footer"><button type="button" className="button secondary" onClick={onClose}>Cancel</button><SubmitButton busy={busy}><Check size={15} />Save my progress</SubmitButton></div></form></Modal>;
}

function ShelfFormDialog({ shelf, onClose }: { shelf?: Shelf; onClose: () => void }) {
  const { data, saveShelf, setDialog } = useLibrary();
  const [name, setName] = useState(shelf?.name ?? "");
  const [description, setDescription] = useState(shelf?.description ?? "");
  const [color, setColor] = useState(shelf?.color ?? "#8a9b7c");
  const [bookIds, setBookIds] = useState(data?.books.filter(book => shelf && book.shelfIds.includes(shelf.id)).map(book => book.id) ?? []);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const colors = ["#c68e68", "#8a9b7c", "#b1a1c6", "#829fba", "#ccae6e", "#c48698"];
  const submit = async (event: FormEvent) => { event.preventDefault(); setBusy(true); setError(null); try { await saveShelf(shelf?.id, { name, description, color, bookIds }); onClose(); } catch (error) { setError(getError(error)); } finally { setBusy(false); } };
  return <Modal title={shelf ? "A shelf, just the way you like it." : "A home for your kind of stories."} subtitle="Organize by mood, meaning, or whatever feels like you." onClose={onClose}><form onSubmit={submit}><label className="field-label">Shelf name <span>*</span><input data-autofocus value={name} onChange={event => setName(event.target.value)} maxLength={60} placeholder="Rainy days & good books" required /></label><label className="field-label">A little description <span className="optional">optional</span><textarea value={description} onChange={event => setDescription(event.target.value)} maxLength={500} rows={2} placeholder="What brings these books together?" /></label><fieldset className="color-picker"><legend>Pick a little color</legend><div>{colors.map(item => <button key={item} type="button" style={{ background: item }} aria-label={`Choose ${item} shelf color`} aria-pressed={color === item} className={color === item ? "selected" : ""} onClick={() => setColor(item)}>{color === item && <Check size={16} />}</button>)}</div></fieldset><div className="shelf-books-label"><label htmlFor="shelf-book-search">Choose your books</label><span>{bookIds.length} selected</span></div><div className="input-with-icon"><Search size={15} /><input id="shelf-book-search" placeholder="Find a book in your library…" value={query} onChange={event => setQuery(event.target.value)} /></div><div className="shelf-book-selector">{data?.books.filter(book => `${book.title} ${book.author}`.toLowerCase().includes(query.toLowerCase())).map(book => <label key={book.id} className="shelf-book-option"><Cover cover={book.cover} title={book.title} /><span><strong>{book.title}</strong><small>{book.author}</small></span><input type="checkbox" checked={bookIds.includes(book.id)} onChange={() => setBookIds(prev => prev.includes(book.id) ? prev.filter(id => id !== book.id) : [...prev, book.id])} /></label>)}{!data?.books.length && <p className="muted">Add a book to your library, then give it a home here.</p>}{Boolean(data?.books.length) && !data?.books.some(book => `${book.title} ${book.author}`.toLowerCase().includes(query.toLowerCase())) && <p className="muted">No books match that search.</p>}</div><FormError error={error} /><div className="modal-footer shelf-form-footer">{shelf && <button className="text-button danger-text" type="button" onClick={() => setDialog({ type: "confirm", resource: "shelf", id: shelf.id, title: shelf.name })}><Trash2 size={14} />Delete shelf</button>}<div><button type="button" className="button secondary" onClick={onClose}>Cancel</button><SubmitButton busy={busy}>{shelf ? "Save shelf" : "Create shelf"}</SubmitButton></div></div></form></Modal>;
}

function GoalDialog({ onClose }: { onClose: () => void }) {
  const { data, updateProfile } = useLibrary();
  const [goal, setGoal] = useState(data?.user.readingGoal ?? 24);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submit = async (event: FormEvent) => { event.preventDefault(); setBusy(true); try { await updateProfile({ readingGoal: goal }); onClose(); } catch (error) { setError(getError(error)); } finally { setBusy(false); } };
  return <Modal title="A year of good company." subtitle="A reading goal is an invitation, not a deadline." onClose={onClose} className="goal-modal"><form onSubmit={submit}><div className="goal-modal-art"><Flower2 size={52} strokeWidth={1} /><span>{new Date().getFullYear()}</span></div><label className="field-label goal-field">How many books would you love to read?<div><input data-autofocus aria-label="Books to read this year" type="number" min={1} max={1000} value={goal || ""} onChange={event => setGoal(Number(event.target.value))} required /><span>books this year</span></div></label><div className="goal-presets">{[{ value: 12, label: "One a month" }, { value: 24, label: "A lovely rhythm" }, { value: 36, label: "A little ambitious" }, { value: 52, label: "One a week" }].map(preset => <button type="button" key={preset.value} className={goal === preset.value ? "active" : ""} onClick={() => setGoal(preset.value)}><strong>{preset.value}</strong><span>{preset.label}</span></button>)}</div><div className="gentle-note"><Leaf size={15} />Your pace is the right pace. You can change this any time.</div><FormError error={error} /><div className="modal-footer"><button className="button secondary" type="button" onClick={onClose}>Cancel</button><SubmitButton busy={busy}><Target size={15} />Set my reading goal</SubmitButton></div></form></Modal>;
}

function AuthDialog({ mode, onClose }: { mode: "login" | "signup"; onClose: () => void }) {
  const { data, refresh, setDialog, notify } = useLibrary();
  const [name, setName] = useState(data?.user.name ?? "");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const signup = mode === "signup";
  const submit = async (event: FormEvent) => { event.preventDefault(); setBusy(true); setError(null); try { await apiRequest(`/api/auth/${mode}`, { method: "POST", body: JSON.stringify({ name, email, password }) }); await refresh(); onClose(); notify(signup ? "Welcome to folio. Your library is officially yours." : "Welcome back. Your stories missed you."); } catch (error) { setError(getError(error)); } finally { setBusy(false); } };
  return <Modal title={signup ? "Make yourself at home." : "Your next chapter awaits."} subtitle={signup ? "A little space for the books that make you, you." : "Welcome back to your own little book world."} onClose={onClose} className="auth-modal"><div className="auth-mark"><BookOpen size={29} strokeWidth={1.4} /><span>folio<span>.</span></span></div>{signup && data?.user.isDemo && <div className="auth-demo-note"><Sparkles size={16} /><p>Your {data.books.length} books, shelves, and reading moments will come with you.</p></div>}<form onSubmit={submit}>{signup && <label className="field-label">Your name<input data-autofocus autoComplete="name" value={name} onChange={event => setName(event.target.value)} maxLength={60} placeholder="What should we call you?" required /></label>}<label className="field-label">Email address<input type="email" autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="you@somewhere.com" required maxLength={254} /></label><label className="field-label">Password<div className="password-field"><input type={showPassword ? "text" : "password"} autoComplete={signup ? "new-password" : "current-password"} value={password} onChange={event => setPassword(event.target.value)} minLength={8} maxLength={128} placeholder={signup ? "At least 8 characters" : "Your secret little key"} required /><button type="button" aria-label={showPassword ? "Hide password" : "Show password"} onClick={() => setShowPassword(!showPassword)}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div></label><FormError error={error} /><SubmitButton busy={busy} className="auth-submit">{signup ? "Create my account" : "Come on in"}<ArrowRight size={15} /></SubmitButton></form><p className="auth-toggle">{signup ? "Already part of the story?" : "New around here?"}<button onClick={() => setDialog({ type: "auth", mode: signup ? "login" : "signup" })}>{signup ? "Sign in" : "Create an account"}</button></p><div className="auth-footer"><LockKeyhole size={12} />Your library, kept safe. No noise. Just books.</div></Modal>;
}

function ConfirmDialog({ resource, id, title, onClose }: { resource: "book" | "shelf" | "log"; id: string; title: string; onClose: () => void }) {
  const { deleteResource } = useLibrary();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const remove = async () => { setBusy(true); try { await deleteResource(resource, id); onClose(); } catch (error) { setError(getError(error)); } finally { setBusy(false); } };
  return <Modal title={resource === "shelf" ? "Let this shelf go?" : resource === "book" ? "Make a little space?" : "Remove this reading moment?"} onClose={onClose} className="confirm-modal"><div className="confirm-icon"><Trash2 size={24} strokeWidth={1.4} /></div><p className="confirm-description">{resource === "book" ? <>Remove <strong>“{title}”</strong> from your library? Its notes, rating, shelf placements, and reading sessions will also be removed.</> : resource === "shelf" ? <>Delete <strong>“{title}”</strong>? Your books will stay safely in your library and on any other shelves.</> : <>Remove this reading session for <strong>“{title}”</strong>? Your current bookmark won’t change.</>}</p><p className="muted">This can’t be undone.</p><FormError error={error} /><div className="modal-footer"><button className="button secondary" onClick={onClose}>Keep it</button><SubmitButton busy={busy} type="button" className="danger-button" onClick={() => void remove()}><Trash2 size={14} />{resource === "book" ? "Remove book" : resource === "shelf" ? "Delete shelf" : "Remove session"}</SubmitButton></div></Modal>;
}

function HelpDialog({ onClose }: { onClose: () => void }) {
  const { setDialog } = useLibrary();
  return <Modal title="A little help for your next chapter." subtitle="Welcome to folio. Make yourself comfortable." onClose={onClose} className="help-modal"><div className="help-intro"><Leaf size={25} /><p>A quieter place to keep your books, follow your curiosity, and celebrate every page.</p></div><div className="help-faqs">{[{ title: "How do I add and organize books?", text: "Choose Add a book to enter the title, author, and page count. Give it a cover image, choose a reading status, and place it on as many shelves as you like. Visit Discover for six thoughtfully curated recommendations you can add in one click." }, { title: "How does reading progress work?", text: "Choose Update progress on a book, enter your current page and reading time, and save. New pages automatically become a reading session in your insights. Reaching the last page marks the book finished and counts it toward your yearly goal." }, { title: "Can I rate books and keep notes?", text: "Open any book and choose up to five stars. Click your current star again to clear the rating. The My notes tab is a private place for thoughts, favorite lines, and anything you want to remember." }, { title: "Will my demo library be saved?", text: "Your demo is personal and saved automatically in this browser for 30 days. Create an account to keep it across devices. Every book, shelf, note, and reading session comes with you when you sign up." }, { title: "Can I take my library with me?", text: "Of course. Open Settings and select Export library to download all your books, shelves, notes, ratings, and reading history as a JSON file." }].map(item => <details key={item.title}><summary>{item.title}<ChevronRight size={15} /></summary><p>{item.text}</p></details>)}</div><div className="help-credit">Book cover imagery courtesy of <a href="https://openlibrary.org" target="_blank" rel="noreferrer">Open Library <ArrowRight size={11} /></a>.</div><div className="modal-footer"><button className="button secondary" onClick={onClose}>Happy reading</button><button className="button primary" onClick={() => setDialog({ type: "book-form" })}><Plus size={15} />Add a book</button></div></Modal>;
}
