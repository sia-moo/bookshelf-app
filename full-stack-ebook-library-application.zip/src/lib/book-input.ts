import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { books, shelves } from "@/db/schema";
import { ApiError, number, safeCover, text, uuid } from "./api";

export function bookInput(body: Record<string, unknown>, create = false) {
  const result: Partial<typeof books.$inferInsert> = {};
  if (create || "title" in body) result.title = text(body.title, "Book title");
  if (create || "author" in body) result.author = text(body.author, "Author");
  if ("cover" in body) result.cover = safeCover(body.cover);
  if ("genre" in body) result.genre = text(body.genre, "Genre", 60);
  if ("description" in body) result.description = text(body.description, "Description", 5000, false);
  if ("notes" in body) result.notes = text(body.notes, "Notes", 20000, false);
  if ("totalPages" in body) result.totalPages = number(body.totalPages, "Page count", 1, 20000);
  if ("currentPage" in body) result.currentPage = number(body.currentPage, "Current page", 0, 20000);
  if ("rating" in body) result.rating = number(body.rating, "Rating", 0, 5);
  if ("status" in body) {
    if (!["want-to-read", "reading", "finished"].includes(String(body.status))) throw new ApiError("Please choose a valid reading status.");
    result.status = String(body.status);
  }
  return result;
}

export async function validateShelfIds(value: unknown, userId: string) {
  if (!Array.isArray(value) || value.length > 50 || value.some(id => typeof id !== "string")) throw new ApiError("Please select valid shelves.");
  const ids = [...new Set(value as string[])].map(uuid);
  if (ids.length) {
    const owned = await db.select({ id: shelves.id }).from(shelves).where(and(eq(shelves.userId, userId), inArray(shelves.id, ids)));
    if (owned.length !== ids.length) throw new ApiError("One of those shelves could not be found.", 404);
  }
  return ids;
}
