import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";

const COOKIE_NAME = "folio_session";
const hashToken = (token: string) => createHash("sha256").update(token).digest("hex");

export async function getUser() {
  const token = (await cookies()).get(COOKIE_NAME)?.value;
  if (!token) return null;
  const [result] = await db.select({ user: users }).from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.token, hashToken(token)), gt(sessions.expiresAt, new Date()))).limit(1);
  return result?.user ?? null;
}

export async function createSession(userId: string) {
  const jar = await cookies();
  const oldToken = jar.get(COOKIE_NAME)?.value;
  if (oldToken) await db.delete(sessions).where(eq(sessions.token, hashToken(oldToken)));
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30);
  await db.insert(sessions).values({ token: hashToken(token), userId, expiresAt });
  jar.set(COOKIE_NAME, token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", expires: expiresAt });
}

export async function clearSession() {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.token, hashToken(token)));
  jar.delete(COOKIE_NAME);
}

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}

export function verifyPassword(password: string, saved: string) {
  const [salt, key] = saved.split(":");
  if (!salt || !key) return false;
  const savedKey = Buffer.from(key, "hex");
  const suppliedKey = scryptSync(password, salt, 64);
  return savedKey.length === suppliedKey.length && timingSafeEqual(savedKey, suppliedKey);
}

export function publicUser(user: typeof users.$inferSelect) {
  return { id: user.id, name: user.name, email: user.isDemo ? "" : user.email, isDemo: user.isDemo, readingGoal: user.readingGoal };
}
