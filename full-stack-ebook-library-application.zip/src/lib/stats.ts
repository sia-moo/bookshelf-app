import type { LibraryData, ReadingLog } from "./types";
const dateKey = (date: Date) => `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
export function getStreak(logs: ReadingLog[]) {
  const days = new Set(logs.filter(log => log.pages > 0).map(log => dateKey(new Date(log.loggedAt))));
  const cursor = new Date();
  if (!days.has(dateKey(cursor))) cursor.setDate(cursor.getDate() - 1);
  let count = 0;
  while (days.has(dateKey(cursor))) { count++; cursor.setDate(cursor.getDate() - 1); }
  return count;
}
export function getStats(data: LibraryData) {
  const year = new Date().getFullYear();
  const completed = data.books.filter(book => book.status === "finished" && book.finishedAt && new Date(book.finishedAt).getFullYear() === year).length;
  const today = new Date();
  const week = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(today); date.setDate(today.getDate() - 6 + index);
    const logs = data.logs.filter(log => dateKey(new Date(log.loggedAt)) === dateKey(date));
    return { label: date.toLocaleDateString("en", { weekday: "short" }), date, pages: logs.reduce((sum, log) => sum + log.pages, 0), minutes: logs.reduce((sum, log) => sum + log.minutes, 0) };
  });
  return { completed, streak: getStreak(data.logs), reading: data.books.filter(book => book.status === "reading").length, week, pages: data.logs.reduce((sum, log) => sum + log.pages, 0), minutes: data.logs.reduce((sum, log) => sum + log.minutes, 0) };
}
export const bookPercent = (current: number, total: number) => Math.min(100, Math.round(current / Math.max(total, 1) * 100));
