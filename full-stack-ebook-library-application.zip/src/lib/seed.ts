import { randomUUID } from "node:crypto";
import { db } from "@/db";
import { users, books, shelves, bookShelves, readingLogs } from "@/db/schema";
import { catalogue } from "./catalog";

export async function createDemoLibrary() {
  return db.transaction(async (tx) => {
    const [user] = await tx.insert(users).values({ name: "Alex Morgan", email: `demo-${randomUUID()}@folio.local`, isDemo: true }).returning();
    const now = new Date();
    const seededBooks = await tx.insert(books).values(catalogue.map((book, i) => {
      const finished = i >= 3 && i < 15;
      const addedAt = new Date(now); addedAt.setDate(now.getDate() - (i + 2));
      const finishedAt = finished ? new Date(now.getFullYear(), Math.max(0, now.getMonth() - 1), 1 + (i - 3) * 2) : null;
      return {
        userId: user.id, title: book.title, author: book.author, cover: `/covers/${book.isbn}.jpg`,
        genre: book.genre, totalPages: book.totalPages, description: book.description,
        currentPage: i === 0 ? 124 : i === 1 ? 208 : i === 2 ? 86 : finished ? book.totalPages : 0,
        status: i < 3 ? "reading" : finished ? "finished" : "want-to-read",
        rating: finished ? [5, 4, 5, 4, 5, 4, 5, 4, 4, 5, 4, 5][i - 3] : i === 0 ? 5 : i === 1 ? 4 : 0,
        notes: i === 1 ? "Make it obvious. Make it attractive. Make it easy. Make it satisfying. A lovely reminder that small, consistent steps really do add up." : i === 3 ? "The most valuable thing money can buy is time. One to come back to." : "",
        addedAt, finishedAt,
      };
    })).returning();
    const seededShelves = await tx.insert(shelves).values([
      { userId: user.id, name: "All-time favorites", color: "#c68e68", description: "The stories that stay with me, long after the last page." },
      { userId: user.id, name: "Slow Sundays", color: "#8a9b7c", description: "A warm cup, a quiet corner, and nowhere else to be." },
      { userId: user.id, name: "Room to grow", color: "#b1a1c6", description: "Fresh perspectives and little nudges toward a better me." },
    ]).returning();
    const memberships = [[0, 3, 6, 9, 13, 18], [0, 4, 7, 19, 20, 22], [1, 2, 5, 8, 10, 11, 12, 16]];
    await tx.insert(bookShelves).values(seededShelves.flatMap((shelf, i) => memberships[i].map(index => ({ bookId: seededBooks[index].id, shelfId: shelf.id }))));
    await tx.insert(readingLogs).values(Array.from({ length: 18 }, (_, i) => {
      const loggedAt = new Date(now); loggedAt.setDate(now.getDate() - i); loggedAt.setHours(18, 30, 0, 0);
      if (i === 0) loggedAt.setTime(now.getTime() - 60000);
      return { userId: user.id, bookId: seededBooks[i % 3].id, pages: 12 + ((i * 7) % 29), minutes: 15 + ((i * 11) % 36), loggedAt };
    }));
    return user;
  });
}
