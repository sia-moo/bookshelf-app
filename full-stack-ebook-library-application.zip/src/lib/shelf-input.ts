import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { books } from "@/db/schema";
import { ApiError, text, uuid } from "./api";
export function shelfInput(body: Record<string, unknown>, create = false) {
  const result: { name?: string; description?: string; color?: string } = {};
  if (create || "name" in body) result.name = text(body.name, "Shelf name", 60);
  if ("description" in body) result.description = text(body.description, "Description", 500, false);
  if ("color" in body) { const color = text(body.color, "Color", 7); if (!/^#[0-9a-f]{6}$/i.test(color)) throw new ApiError("Please choose a valid shelf color."); result.color = color; }
  return result;
}
export async function validateBookIds(value: unknown, userId: string) {
  if (!Array.isArray(value) || value.length > 1000 || value.some(id => typeof id !== "string")) throw new ApiError("Please select valid books.");
  const ids = [...new Set(value as string[])].map(uuid);
  if (ids.length) {
    const owned = await db.select({ id: books.id }).from(books).where(and(eq(books.userId, userId), inArray(books.id, ids)));
    if (owned.length !== ids.length) throw new ApiError("One of those books could not be found.", 404);
  }
  return ids;
}
