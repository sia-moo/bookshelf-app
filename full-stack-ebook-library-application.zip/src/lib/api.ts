import { getUser } from "./auth";

export class ApiError extends Error {
  constructor(message: string, public status = 400) { super(message); }
}
export async function requireUser() {
  const user = await getUser();
  if (!user) throw new ApiError("Your session has expired. Please refresh or sign in again.", 401);
  return user;
}
export function errorResponse(error: unknown) {
  if (error instanceof ApiError) return Response.json({ error: error.message }, { status: error.status });
  console.error("Folio API error:", error);
  return Response.json({ error: "Something went wrong. Please try again in a moment." }, { status: 500 });
}
export function text(value: unknown, label: string, max = 250, required = true): string {
  if (typeof value !== "string" || (required && !value.trim())) throw new ApiError(`${label} is required.`);
  if (value.length > max) throw new ApiError(`${label} must be less than ${max} characters.`);
  return value.trim();
}
export function number(value: unknown, label: string, min: number, max: number): number {
  if (typeof value !== "number" || !Number.isInteger(value) || value < min || value > max) throw new ApiError(`${label} must be a whole number between ${min} and ${max}.`);
  return value;
}
export function uuid(value: string) {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) throw new ApiError("That item could not be found.", 404);
  return value;
}
export function safeCover(value: unknown) {
  if (!value) return "";
  const cover = text(value, "Cover URL", 2000, false);
  if (cover.startsWith("/covers/")) return cover;
  try { const url = new URL(cover); if (url.protocol === "https:" || url.protocol === "http:") return cover; } catch {}
  throw new ApiError("Please enter a valid https cover image URL.");
}
export async function readBody(request: Request): Promise<Record<string, unknown>> {
  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (contentLength > 50000) throw new ApiError("That request is too large.", 413);
  try { const data = await request.json(); if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error(); return data; }
  catch { throw new ApiError("Please send a valid request."); }
}
