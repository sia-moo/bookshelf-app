export type BookStatus = "want-to-read" | "reading" | "finished";
export type Book = {
  id: string; userId: string; title: string; author: string; cover: string;
  genre: string; totalPages: number; currentPage: number; status: BookStatus;
  rating: number; notes: string; description: string; addedAt: string; finishedAt: string | null;
  shelfIds: string[];
};
export type Shelf = { id: string; name: string; color: string; description: string };
export type ReadingLog = { id: string; bookId: string; pages: number; minutes: number; loggedAt: string };
export type User = { id: string; name: string; email: string; isDemo: boolean; readingGoal: number };
export type LibraryData = { user: User; books: Book[]; shelves: Shelf[]; logs: ReadingLog[] };
export type CatalogBook = { title: string; author: string; isbn: string; genre: string; totalPages: number; description: string };
export const statusLabels: Record<BookStatus, string> = { "want-to-read": "Want to read", reading: "Currently reading", finished: "Finished" };
export const genres = ["Fiction", "Personal growth", "Psychology", "Memoir", "Fantasy", "Mystery", "Nonfiction", "Science fiction"];
