import { pgTable, uuid, text, integer, boolean, timestamp, primaryKey } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash"),
  isDemo: boolean("is_demo").notNull().default(true),
  readingGoal: integer("reading_goal").notNull().default(24),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
});

export const books = pgTable("books", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  author: text("author").notNull(),
  cover: text("cover").notNull().default(""),
  genre: text("genre").notNull().default("Fiction"),
  totalPages: integer("total_pages").notNull().default(300),
  currentPage: integer("current_page").notNull().default(0),
  status: text("status").notNull().default("want-to-read"),
  rating: integer("rating").notNull().default(0),
  notes: text("notes").notNull().default(""),
  description: text("description").notNull().default(""),
  addedAt: timestamp("added_at").notNull().defaultNow(),
  finishedAt: timestamp("finished_at"),
});

export const shelves = pgTable("shelves", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  color: text("color").notNull().default("#80957a"),
  description: text("description").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const bookShelves = pgTable("book_shelves", {
  bookId: uuid("book_id").notNull().references(() => books.id, { onDelete: "cascade" }),
  shelfId: uuid("shelf_id").notNull().references(() => shelves.id, { onDelete: "cascade" }),
}, (table) => [primaryKey({ columns: [table.bookId, table.shelfId] })]);

export const readingLogs = pgTable("reading_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  bookId: uuid("book_id").notNull().references(() => books.id, { onDelete: "cascade" }),
  pages: integer("pages").notNull(),
  minutes: integer("minutes").notNull().default(20),
  loggedAt: timestamp("logged_at").notNull().defaultNow(),
});
