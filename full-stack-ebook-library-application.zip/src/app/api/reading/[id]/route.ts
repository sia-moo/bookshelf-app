import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { readingLogs } from "@/db/schema";
import { ApiError, errorResponse, requireUser, uuid } from "@/lib/api";
export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser(); const { id } = await params; uuid(id);
    const [deleted] = await db.delete(readingLogs).where(and(eq(readingLogs.id, id), eq(readingLogs.userId, user.id))).returning({ id: readingLogs.id });
    if (!deleted) throw new ApiError("That reading session could not be found.", 404);
    return Response.json({ ok: true });
  } catch (error) { return errorResponse(error); }
}
