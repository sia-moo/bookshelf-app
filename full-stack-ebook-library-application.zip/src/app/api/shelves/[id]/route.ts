import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { shelves, bookShelves } from "@/db/schema";
import { ApiError, errorResponse, readBody, requireUser, uuid } from "@/lib/api";
import { shelfInput, validateBookIds } from "@/lib/shelf-input";
type Context = { params: Promise<{ id: string }> };
export async function PATCH(request: Request, { params }: Context) {
  try {
    const user = await requireUser(); const { id } = await params; uuid(id);
    const [existing] = await db.select().from(shelves).where(and(eq(shelves.id, id), eq(shelves.userId, user.id))).limit(1);
    if (!existing) throw new ApiError("This shelf could not be found.", 404);
    const body = await readBody(request); const input = shelfInput(body);
    const bookIds = body.bookIds !== undefined ? await validateBookIds(body.bookIds, user.id) : undefined;
    const shelf = await db.transaction(async tx => {
      const [updated] = await tx.update(shelves).set({ name: existing.name, ...input }).where(eq(shelves.id, id)).returning();
      if (bookIds !== undefined) {
        await tx.delete(bookShelves).where(eq(bookShelves.shelfId, id));
        if (bookIds.length) await tx.insert(bookShelves).values(bookIds.map(bookId => ({ bookId, shelfId: id })));
      }
      return updated;
    });
    return Response.json({ shelf, bookIds });
  } catch (error) { return errorResponse(error); }
}
export async function DELETE(_request: Request, { params }: Context) {
  try {
    const user = await requireUser(); const { id } = await params; uuid(id);
    const [deleted] = await db.delete(shelves).where(and(eq(shelves.id, id), eq(shelves.userId, user.id))).returning({ id: shelves.id });
    if (!deleted) throw new ApiError("This shelf could not be found.", 404);
    return Response.json({ ok: true });
  } catch (error) { return errorResponse(error); }
}
