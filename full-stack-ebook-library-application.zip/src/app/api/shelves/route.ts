import { db } from "@/db";
import { shelves, bookShelves } from "@/db/schema";
import { errorResponse, readBody, requireUser } from "@/lib/api";
import { shelfInput, validateBookIds } from "@/lib/shelf-input";
export async function POST(request: Request) {
  try {
    const user = await requireUser(); const body = await readBody(request);
    const input = shelfInput(body, true);
    const bookIds = await validateBookIds(body.bookIds ?? [], user.id);
    const shelf = await db.transaction(async tx => {
      const [created] = await tx.insert(shelves).values({ ...input, userId: user.id, name: input.name! }).returning();
      if (bookIds.length) await tx.insert(bookShelves).values(bookIds.map(bookId => ({ bookId, shelfId: created.id })));
      return created;
    });
    return Response.json({ shelf, bookIds }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}
