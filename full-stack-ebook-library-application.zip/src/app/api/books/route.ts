import { db } from "@/db";
import { books, bookShelves } from "@/db/schema";
import { ApiError, errorResponse, readBody, requireUser } from "@/lib/api";
import { bookInput, validateShelfIds } from "@/lib/book-input";

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const body = await readBody(request);
    const input = bookInput(body, true);
    const shelfIds = await validateShelfIds(body.shelfIds ?? [], user.id);
    const totalPages = input.totalPages ?? 300;
    const status = input.status ?? "want-to-read";
    const currentPage = status === "finished" ? totalPages : status === "want-to-read" ? 0 : input.currentPage ?? 0;
    if (currentPage > totalPages) throw new ApiError("The current page can't be higher than the book's page count.");
    const book = await db.transaction(async (tx) => {
      const [created] = await tx.insert(books).values({ ...input, userId: user.id, title: input.title!, author: input.author!, totalPages, currentPage, status, finishedAt: status === "finished" ? new Date() : null }).returning();
      if (shelfIds.length) await tx.insert(bookShelves).values(shelfIds.map(shelfId => ({ bookId: created.id, shelfId })));
      return created;
    });
    return Response.json({ book: { ...book, shelfIds } }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}
