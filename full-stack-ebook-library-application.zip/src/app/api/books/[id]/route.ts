import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { books, bookShelves, readingLogs } from "@/db/schema";
import { ApiError, errorResponse, number, readBody, requireUser, uuid } from "@/lib/api";
import { bookInput, validateShelfIds } from "@/lib/book-input";

type Context = { params: Promise<{ id: string }> };
export async function PATCH(request: Request, { params }: Context) {
  try {
    const user = await requireUser();
    const { id } = await params; uuid(id);
    const [existing] = await db.select().from(books).where(and(eq(books.id, id), eq(books.userId, user.id))).limit(1);
    if (!existing) throw new ApiError("This book could not be found.", 404);
    const body = await readBody(request);
    const input = bookInput(body);
    const totalPages = input.totalPages ?? existing.totalPages;
    let currentPage = input.currentPage ?? existing.currentPage;
    let status = input.status ?? existing.status;
    if (input.status === "want-to-read") currentPage = 0;
    else if (input.status === "finished") currentPage = totalPages;
    else if (input.status === "reading" && existing.status === "finished" && input.currentPage === undefined) currentPage = 0;
    if (currentPage > totalPages) throw new ApiError("The current page can't be higher than the book's page count.");
    if (input.currentPage !== undefined && currentPage === totalPages) status = "finished";
    else if (input.currentPage !== undefined && currentPage > 0 && status === "want-to-read") status = "reading";
    if (status === "finished" && currentPage < totalPages) status = "reading";
    const shelfIds = body.shelfIds !== undefined ? await validateShelfIds(body.shelfIds, user.id) : undefined;
    const minutes = body.minutes !== undefined ? number(body.minutes, "Reading time", 1, 1440) : Math.max(1, Math.round((currentPage - existing.currentPage) / 2));
    const result = await db.transaction(async (tx) => {
      const [book] = await tx.update(books).set({ ...input, currentPage, status, finishedAt: status === "finished" ? existing.finishedAt ?? new Date() : null }).where(eq(books.id, id)).returning();
      let log = null;
      if (currentPage > existing.currentPage) {
        [log] = await tx.insert(readingLogs).values({ userId: user.id, bookId: id, pages: currentPage - existing.currentPage, minutes }).returning();
      }
      if (shelfIds !== undefined) {
        await tx.delete(bookShelves).where(eq(bookShelves.bookId, id));
        if (shelfIds.length) await tx.insert(bookShelves).values(shelfIds.map(shelfId => ({ bookId: id, shelfId })));
      }
      const memberships = await tx.select().from(bookShelves).where(eq(bookShelves.bookId, id));
      return { book: { ...book, shelfIds: memberships.map(m => m.shelfId) }, log };
    });
    return Response.json(result);
  } catch (error) { return errorResponse(error); }
}
export async function DELETE(_request: Request, { params }: Context) {
  try {
    const user = await requireUser(); const { id } = await params; uuid(id);
    const [book] = await db.delete(books).where(and(eq(books.id, id), eq(books.userId, user.id))).returning({ id: books.id });
    if (!book) throw new ApiError("This book could not be found.", 404);
    return Response.json({ ok: true });
  } catch (error) { return errorResponse(error); }
}
