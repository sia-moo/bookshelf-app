import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getUser, createSession, clearSession, hashPassword, verifyPassword, publicUser } from "@/lib/auth";
import { ApiError, errorResponse, readBody, text } from "@/lib/api";

const attempts = new Map<string, { count: number; reset: number }>();
export async function POST(request: Request, { params }: { params: Promise<{ action: string }> }) {
  try {
    const { action } = await params;
    if (action === "logout") { await clearSession(); return Response.json({ ok: true }); }
    if (action !== "login" && action !== "signup") throw new ApiError("Not found.", 404);
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0] ?? "local";
    const previous = attempts.get(ip);
    const attempt = previous && previous.reset > Date.now() ? previous : { count: 0, reset: Date.now() + 900000 };
    if (++attempt.count > 25) throw new ApiError("A few too many attempts. Please try again in 15 minutes.", 429);
    attempts.set(ip, attempt);
    const body = await readBody(request);
    const email = text(body.email, "Email", 254).toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new ApiError("Please enter a valid email address.");
    const password = text(body.password, "Password", 128);
    if (password.length < 8) throw new ApiError("Your password needs at least 8 characters.");
    const [existing] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (action === "login") {
      if (!existing?.passwordHash || !verifyPassword(password, existing.passwordHash)) throw new ApiError("That email and password don't match. Please try again.", 401);
      await createSession(existing.id);
      attempts.delete(ip);
      return Response.json({ user: publicUser(existing) });
    }
    if (existing) throw new ApiError("An account with that email already exists. Try signing in.", 409);
    const name = text(body.name, "Name", 60);
    const current = await getUser();
    const values = { name, email, passwordHash: hashPassword(password), isDemo: false };
    const [user] = current?.isDemo
      ? await db.update(users).set(values).where(eq(users.id, current.id)).returning()
      : await db.insert(users).values(values).returning();
    await createSession(user.id);
    attempts.delete(ip);
    return Response.json({ user: publicUser(user) }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}
