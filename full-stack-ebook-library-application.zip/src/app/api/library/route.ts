import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { books, shelves, bookShelves, readingLogs } from "@/db/schema";
import { createSession, getUser, publicUser } from "@/lib/auth";
import { createDemoLibrary } from "@/lib/seed";
import { errorResponse } from "@/lib/api";

export const dynamic = "force-dynamic";
export async function GET() {
  try {
    let user = await getUser();
    if (!user) { user = await createDemoLibrary(); await createSession(user.id); }
    const [userBooks, userShelves, memberships, logs] = await Promise.all([
      db.select().from(books).where(eq(books.userId, user.id)).orderBy(desc(books.addedAt)),
      db.select().from(shelves).where(eq(shelves.userId, user.id)).orderBy(shelves.createdAt),
      db.select({ bookId: bookShelves.bookId, shelfId: bookShelves.shelfId }).from(bookShelves).innerJoin(shelves, eq(shelves.id, bookShelves.shelfId)).where(eq(shelves.userId, user.id)),
      db.select().from(readingLogs).where(eq(readingLogs.userId, user.id)).orderBy(desc(readingLogs.loggedAt)),
    ]);
    return Response.json({ user: publicUser(user), books: userBooks.map(book => ({ ...book, shelfIds: memberships.filter(m => m.bookId === book.id).map(m => m.shelfId) })), shelves: userShelves, logs }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) { return errorResponse(error); }
}
