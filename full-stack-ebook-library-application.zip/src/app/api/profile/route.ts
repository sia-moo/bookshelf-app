import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { errorResponse, number, readBody, requireUser, text } from "@/lib/api";
import { publicUser } from "@/lib/auth";
export async function PATCH(request: Request) {
  try {
    const user = await requireUser(); const body = await readBody(request);
    const values: Partial<typeof users.$inferInsert> = {};
    if ("readingGoal" in body) values.readingGoal = number(body.readingGoal, "Reading goal", 1, 1000);
    if ("name" in body) values.name = text(body.name, "Name", 60);
    if (!Object.keys(values).length) return Response.json({ user: publicUser(user) });
    const [updated] = await db.update(users).set(values).where(eq(users.id, user.id)).returning();
    return Response.json({ user: publicUser(updated) });
  } catch (error) { return errorResponse(error); }
}
