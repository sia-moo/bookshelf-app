"use client";

import { BookOpen, RotateCcw } from "lucide-react";

export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <main className="not-found-page" id="main-content"><BookOpen size={44} strokeWidth={1.2} /><span className="eyebrow">JUST A LITTLE PAUSE</span><h1>Let’s pick up where we left off.</h1><p>Your books are safely saved. Something on this page needs a fresh start.</p><button className="button primary" onClick={reset}><RotateCcw size={15} />Try this chapter again</button><a href="/" className="text-button" style={{ marginTop: 20 }}>Back to your library</a></main>;
}
