import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "folio — Your own little book world",
  description: "A quieter place for your books. Curate your personal bookshelf, track your reading, save your thoughts, and discover your next favorite with folio.",
  icons: { icon: "/icon.svg" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head><link rel="stylesheet" href="/fonts/fonts.css" /></head>
      <body><a className="skip-link" href="#main-content">Skip to your library</a>{children}</body>
    </html>
  );
}
