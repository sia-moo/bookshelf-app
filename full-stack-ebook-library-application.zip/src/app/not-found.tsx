import Link from "next/link";
import { BookOpen, ArrowLeft } from "lucide-react";
export default function NotFound() {
  return <main className="not-found-page"><BookOpen size={44} strokeWidth={1.2} /><span className="eyebrow">A LITTLE LOST IN THE STACKS</span><h1>This chapter hasn’t been written.</h1><p>Let’s find our way back to a familiar shelf.</p><Link href="/" className="button primary"><ArrowLeft size={16} />Back to your library</Link></main>;
}
