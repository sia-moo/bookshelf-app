import LibraryApp from "@/components/library-app";

export default function HomePage() {
  return <LibraryApp />;
}
